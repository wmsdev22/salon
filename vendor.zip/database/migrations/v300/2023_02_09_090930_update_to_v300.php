<?php
/*
 * File name: 2023_02_09_090930_update_to_v300.php
 * Last modified: 2023.02.09 at 20:36:50
 * Author: SmarterVision - https://codecanyon.net/user/smartervision
 * Copyright (c) 2023
 */

use Illuminate\Database\Migrations\Migration;

class UpdateToV300 extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
    }
}
